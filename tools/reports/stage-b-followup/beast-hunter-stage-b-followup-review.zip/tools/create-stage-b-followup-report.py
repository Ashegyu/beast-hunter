from pathlib import Path
import json, re, zipfile

root=Path(__file__).resolve().parent.parent
folder=root/'tools/reports/stage-b-followup'
before=json.loads((folder/'balance-before.json').read_text())
after=json.loads((folder/'balance-after.json').read_text())
cpu_before=json.loads((folder/'cpu-before.json').read_text())
cpu_after=json.loads((folder/'cpu-after.json').read_text())
metrics=json.loads(cpu_after['data']['frameMetrics'])
def passed(name):
    text=(folder/name).read_text()
    total=int(re.findall(r'ℹ tests (\d+)',text)[-1])
    successes=int(re.findall(r'ℹ pass (\d+)',text)[-1])
    failed=int(re.findall(r'ℹ fail (\d+)',text)[-1])
    assert total==successes and failed==0,name
    return total
engine=passed('engine-tests-final.log')
ui=passed('ui-full-tests-final.log')
total=engine+ui
rows=[]
for key,title in [((1,9),'밀집 특수'),((2,4),'중장갑 특수'),((3,8),'혼합 정예'),((1,10),'숲 보스'),((2,10),'폐성 보스'),((3,10),'빙하 보스')]:
    items={r['build']:r for r in after['summary'] if (r['chapter'],r['stage'])==key}
    values=''.join(f"<td>{items[k]['time']:.2f}초 / HP {items[k]['hp']*100:.1f}%</td>" for k in ['horde','boss','survival'])
    rows.append(f'<tr><th>{key[0]}-{key[1]} {title}</th>{values}</tr>')
paragraphs=f'''<p class="kicker">괴수 사냥꾼 · ALPHA 0.98.1 · 2026-10-23</p>
<h1>단계 B 후속 수정 보고</h1>
<p class="lead">방어 약화의 보스 태세 적용, 저장 성공 후 스테이지 전환, 실패 보상 안내를 수정했습니다. 입력 반응을 유지하며 반복 DOM 쓰기와 가려진 배경 렌더링을 줄였습니다. 자동 테스트 {total}개와 실제 엔진 시뮬레이션 234회를 확인했습니다. 최종 네 가지 화면 크기의 시각 재검증은 원격 브라우저 오류로 완료하지 못했습니다.</p>
<h2>1. 실제 프로젝트와 범위</h2>
<p>기존 Sites 프로젝트 <code>appgprj_6acc7d4700248191a7337e7dcf529731</code>, 기존 공개 주소를 유지합니다. 시작 소스는 공개 버전 150의 <code>88d5a2ea62b30550bae4332541abc2d66b021962</code>입니다. 이번 작업은 앞서 남은 단계 B의 계산·전환·성능 진단 보완입니다. 단계 C의 성장 던전은 구현하지 않았습니다. 새 아트·등급·재화·강화 규칙을 추가하지 않았습니다.</p>
<h2>2. 실제 수정한 동작</h2>
<ul><li><strong>보스 방어 약화:</strong> 기존에는 폐성 보스의 피해 70% 감소가 별도 곱셈으로 처리되어 각인의 장갑 약화를 무시했습니다. 방어 태세의 감소율에도 약화를 적용합니다. 각인 1개의 20%p 약화로 방어 태세 감소율이 70%에서 50%가 됩니다. 최대 40%p 약화 시 30% 감소입니다. 추가 취약 배율·지속 시간·중첩 상한은 유지합니다. HUD는 현재 감소율과 약화 수치를 함께 보여줍니다.</li>
<li><strong>저장 후 다음 스테이지:</strong> 스테이지 완료 정산은 저장 성공 확인에서 다음 구간 준비까지 한 번만 수행합니다. 이때 전리품 표시와 완료 알림을 보존하고 이전 조작 입력을 해제합니다. 저장을 기다리는 동안 진행도·해금은 확정되지 않습니다. 저장 실패 시 정지·재시도 정책을 유지합니다.</li>
<li><strong>정산 지연:</strong> 정산 후보가 생기면 즉시 저장을 시도합니다. 성공 후 갱신된 화면을 표시합니다. 저장 실패 상태에서는 기존 재시도 간격과 수동 재시도를 따릅니다.</li>
<li><strong>전리품 소유 확인:</strong> 정산 후 복제된 인벤토리에서도 ID와 아이템 정의·원화·이름이 일치하면 보관으로 표시합니다. 같은 ID를 가진 다른 테스트 객체를 보유한 경우를 구분합니다.</li>
<li><strong>실패 안내:</strong> 특수·정예·보스 실패 결과에 남은 몬스터 수, 현재 구간 보상 미지급, 앞서 완료한 구간 보상 유지, 60초 재도전을 함께 표시합니다.</li>
<li><strong>획득 안내:</strong> 예전 보스 고대 드롭 확률 안내를 현재의 일반 장비·승급·추후 레이드 획득 정책으로 바로잡았습니다.</li>
<li><strong>반복 작업 절감:</strong> 물리·공격·쿨다운·HUD 확인은 매 프레임 유지합니다. 바뀐 문구만 DOM에 기록해 동일 텍스트 노드의 반복 교체를 줄입니다. 일러스트 화면으로 가려진 캠프에서는 전장 캔버스를 그리지 않습니다. 초당 UI 갱신 횟수를 낮추는 방식은 최종 코드에 적용하지 않았습니다.</li>
<li><strong>진단:</strong> 120개 표본으로 CPU, 엔진, 렌더링/오디오, HUD, 저장 처리와 실제 rAF 간격을 분리 기록합니다. 메모리는 고정 크기 배열로 제한합니다. 개발 진단은 화면 사용자 흐름에 노출하지 않습니다.</li></ul>
<h2>3. 구현하지 않은 항목과 남은 일</h2>
<p>성장 던전 4종, 엔드 콘텐츠 해금·레이드·도전의 탑·나머지 엔드 콘텐츠는 단계 C~E 범위로 남았습니다. 모든 보스에 대해 빌드별 20~40% 우위를 달성했다고 판정하지 않습니다. 실기기 FPS·GPU·장시간 메모리도 검증하지 못했습니다.</p>
<h2>4. 기존 규칙과 결정값</h2>
<p>각인 피해·중첩·지속 시간, 기본 공격, 강화/승급 비용과 장비 수치를 바꾸지 않았습니다. 폐성 보스의 기존 8초 방어/4초 약점, 약점 피해 +50%를 유지합니다. 일반 구간의 기존 중도 보상 정책과 특수·정예·보스의 실패 보상 없음 정책도 유지합니다. 밸런스 수치를 맞추기 위한 별도 기본 능력치 상향은 적용하지 않았습니다.</p>
<h2>5. 세이브 호환성과 화면 검증</h2>
<p>키 <code>beast-hunter:profile:v1</code>과 스키마 12를 유지합니다. 기존 세이브 샘플의 장비 ID·강화·재료·진행·다섯 프리셋 복구를 재검사했습니다. 사용자 기기의 세이브를 읽거나 백업하지 않았으며, 테스트용 세이브만 사용했습니다.</p>
<p><strong>시각 재검증 미완료:</strong> 844×390의 단일 QA 탭에서 변경 전후 전투 CPU 표본을 수집했습니다. 최종 보스 HUD·실패 화면을 667×375, 740×360, 844×390, 932×430에서 다시 캡처하려는 도중 브라우저 런타임이 <code>credential_state_unavailable</code> 오류를 반환했습니다. 안내된 런타임 재시작 후에도 로컬 검증 페이지 탐색이 시간 초과했습니다. 사용자 로그인이나 사용자 PC 작업으로 우회하지 않았습니다. 이전 0.98.0의 28장 증거를 이번 버전의 최종 검증으로 재사용하지 않습니다. 새 CSS 레이아웃 변경은 없지만, 바뀐 보스 상태·실패 문구의 실제 줄바꿈 확인은 남습니다.</p>
<h2>6. 테스트·측정 결과</h2>
<p><strong>{total}/{total} 통과:</strong> 엔진·장비·스킬·저장 {engine}개, 전체 UI 통합 {ui}개입니다. 이전 부분 검사에서 실행하지 않았던 오래된 UI 테스트를 전체 검사에 포함했습니다. 현재 요구사항인 9개 장착 위치, 고대 75종, 고대 장비의 레이드 획득, stageType 표시에 맞춰 기존 테스트 기준을 갱신했습니다. 캠페인 자동 전투 테스트는 적의 수치를 바꾸지 않고 충분히 성장한 실제 플레이어 구성으로 진행합니다.</p>
<p>새 회귀 검사는 보스 방어 약화의 최초 적중/상한/만료/약점 구간, 저장 성공 전 해금 금지, 저장 실패 후 1회 정산, 다음 구간 입력 해제·완료 알림·전리품 유지, 동일 문구의 DOM 쓰기 생략과 값 변경 즉시 반영, 축전·궁극기 준비 표시, 특수 실패 보상 안내를 포함합니다. 파서·공백 검사도 수행했습니다.</p>
<h3>빌드별 평균 시간 / 남은 HP</h3>
<table><tr><th>콘텐츠</th><th>대군</th><th>보스</th><th>생존</th></tr>{''.join(rows)}</table>
<p>같은 능력치의 실제 엔진 자동 전투, 각인 차이 분리를 위한 스킬 시전 비활성, 콘텐츠/빌드별 고정 시드 10개입니다. 기본 180/180, 공격력·최대 HP +25% 보조 표본 54/54가 클리어했습니다. 이 보조 표본을 전체 콘텐츠의 권장 전투력 +25% 검증으로 해석하지 않습니다.</p>
<p>폐성 보스의 보스 빌드는 이전 평균 8.94초에서 8.01초로 약 10.4% 개선됐습니다. 대군 빌드 10.23초보다 약 21.7% 빠릅니다. 다만 생존 빌드 9.07초와의 차이는 약 11.7%입니다. 숲·빙하 보스의 시간 차이와 중장갑/정예에서 대군 빌드 우세는 여전히 전체 20~40% 목표 밖입니다. 현재 판정은 <strong>일부 개선, 전체 밸런스 합격 아님</strong>입니다.</p>
<h3>단일 탭 CPU 표본</h3>
<table><tr><th>항목</th><th>변경 전</th><th>최종 코드 관측</th></tr><tr><td>전체 프레임 CPU p95</td><td>{float(cpu_before['data']['cpuP95Ms']):.1f} ms</td><td>{metrics['cpuP95']:.1f} ms</td></tr><tr><td>전체 CPU 최대</td><td>{float(cpu_before['data']['cpuMaxMs']):.1f} ms</td><td>{metrics['cpuMax']:.1f} ms</td></tr><tr><td>엔진 / 렌더링 / HUD p95</td><td>구간 분리 없음</td><td>{metrics['engineP95']:.1f} / {metrics['drawP95']:.1f} / {metrics['hudP95']:.1f} ms</td></tr><tr><td>실제 rAF 간격 중앙값</td><td>미수집</td><td>{metrics['intervalP50']:.1f} ms</td></tr></table>
<p>같은 QA 세이브·3-8 자동 전투의 120개 표본입니다. 캐시·원격 스케줄링·실행 부하가 통제된 기기 벤치마크가 아니므로 감소율을 성능 보장으로 제시하지 않습니다. rAF 간격이 약 1초로 관측된 이 실행 환경에서는 실기기 FPS를 판정할 수 없습니다. 렌더링 비용이 주된 추가 점검 대상입니다. 원본 JSON을 함께 제공합니다.</p>
<h2>7. 적용 주소와 자료</h2>
<p><a href="https://beast-hunter-motion.jeagyouns.chatgpt.site">https://beast-hunter-motion.jeagyouns.chatgpt.site</a> · 최종 배포 성공 여부와 저장 버전은 작업 완료 메시지를 기준으로 확인합니다. 검증 HTML은 배포 파일에서 제거합니다. 이 보고서와 원시 측정·최종 로그·재현 스크립트는 같은 소스 저장소에 보존합니다.</p>
<h2>8. 다음 작업</h2>
<p>브라우저 정상화 후 변경 문구의 네 가지 가로 화면 확인을 먼저 마무리할 수 있습니다. 이후 단계 C를 진행하면 기존 재료와 연결되는 성장 던전 4종을 추가합니다. 수치 변경이 필요한 나머지 빌드 밸런스와 저사양 실기기 렌더링 검증은 별도 잔여 항목입니다.</p>
'''
css='body{margin:0;background:#0b1219;color:#dcd7c9;font:15px/1.85 system-ui,sans-serif}main{max-width:1080px;margin:auto;padding:40px 24px}h1,h2,h3{color:#e8c790;line-height:1.4}h1{font-size:34px}h2{margin-top:38px;border-top:1px solid #65513c;padding-top:22px}.kicker{letter-spacing:2px;font-size:12px;color:#b89e70}.lead{font-size:19px}table{border-collapse:collapse;width:100%;font-size:13px}th,td{border:1px solid #565044;padding:10px;text-align:left}th{background:#1c272d}li{margin:10px 0}a{color:#ecc58a}code{overflow-wrap:anywhere;font-size:12px}@media(max-width:700px){main{padding:24px 15px}h1{font-size:27px}table{font-size:11px}th,td{padding:6px}}'
target=folder/'beast-hunter-stage-b-followup-report.html'
target.write_text(f'<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>단계 B 후속 수정 보고</title><style>{css}</style><main>{paragraphs}</main></html>')
archive=folder/'beast-hunter-stage-b-followup-review.zip'
files=[target,*[folder/n for n in ['balance-before.json','balance-after.json','cpu-before.json','cpu-after.json','engine-tests-final.log','ui-full-tests-final.log']],root/'tools/simulate-stage-b.mjs',root/'tools/qa-followup.html',Path(__file__),root/'tests/frame-metrics.test.mjs']
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for path in files:z.write(path,path.relative_to(root))
print('Tests:',total,'Report:',target,'ZIP:',archive)
