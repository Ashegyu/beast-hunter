Alpha 0.97.0 equipment resources
New art: built-in image_gen tool, transparent RGBA atlas. Original existing item images are retained.
Frame coordinates: dist/assets/equipment-parts-v0970.json. Final prompt/method: tools/reports/equipment-system-alpha0970-imagegen.txt.
Nine wearable positions cover eight item types. Earrings share one item type and have two independent wearable positions; one instance cannot be worn twice.
Stage deliveries are common weapon/armor only. Dungeon and raid acquisition are future content. All parts have separate ancient and crafted identities.
The runtime uses clipped atlas frames; the accessory necklace artwork is supplied for reuse while existing necklace artwork is preserved.
